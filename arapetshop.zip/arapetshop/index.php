<!DOCTYPE html>
<html lang="en">
<?php
session_start();
require_once "koneksi.php";
require_once "functions.php";

// Check if the user is already logged in
if (isset($_SESSION['user'])) {
  header("Location: src/views/Dashboard.php");
  exit;
}

if (isset($_POST['login'])) {
  $name = $_POST['name'];
  $password = $_POST['password'];

  $error = login($conn, $name, $password);
}


?>

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Ara Petshop</title>

  <!-- Favicons -->
  <link href="src/assets/favicon.ico" rel="icon">
  <!-- <link href="src/assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="src/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="src/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="src/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="./src/assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="src/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="./src/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="src/assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="src/assets/css/style.css" rel="stylesheet">
</head>

<body>

  <main>
    <div class="container">

      <section class="section register min-vh-100 d-flex flex-column align-items-center justify-content-center py-4">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-6 col-md-6 d-flex flex-column align-items-center justify-content-center">

              <div class="d-flex justify-content-center py-4">
                <a href="index.html" class="logo d-flex align-items-center w-auto">
                  <img src="src/assets/favicon.ico" alt="">
                  <span class="d-none d-lg-block">Ara Petshop</span>
                </a>
              </div><!-- End Logo -->

              <div class="card mb-3">

                <div class="card-body">

                  <div class="pt-4 pb-2">
                    <h5 class="card-title text-center pb-0 fs-4">Masuk untuk melanjutkan</h5>
                    <p class="text-center small">Masukan username & password</p>
                  </div>
                  <?php if (isset($error)) { ?>
                    <div id="error-alert" class="alert alert-danger" role="alert">
                      <?php echo $error; ?>
                    </div>
                  <?php } ?>




                  <form class="row g-3 needs-validations" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="mb-3">
                      <label for="text" class="form-label">Username</label>
                      <input type="text" class="form-control" id="name" name="name" placeholder="Masukan username" required autocomplete="off">
                    </div>
                    <div class="mb-3">
                      <label for="password" class="form-label">Password</label>
                      <input type="password" class="form-control" id="password" name="password" placeholder="Masukan password" required>
                    </div>

                    <div class="d-grid">
                      <button type="submit" class="btn btn-primary" name="login">
                        <i class="bi bi-box-arrow-in-right"></i>
                        Masuk
                      </button>
                    </div>
                  </form>



                </div>
              </div>

              <div class="credits">
                Redesign from <a href="https://bootstrapmade.com/">BootstrapMade</a>
              </div>

            </div>
          </div>
        </div>

      </section>

    </div>
  </main><!-- End #main -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="src/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Template Main JS File -->
  <script src="src/assets/js/main.js"></script>
  <script>
    setTimeout(function() {
      var errorMessage = document.getElementById("error-alert");
      if (errorMessage) {
        errorMessage.style.display = "none";
      }
    }, 3000)
  </script>

</body>

</html>