<?php
session_start();
require_once "../../functions.php";
require_once "../../koneksi.php";

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}
if (isset($_POST['logout'])) {
  logout();
}

// get data barang
$connection = mysqli_connect($servername, $username, $password, $database);
$query2 = 'SELECT kategori.id_kategori, kategori.nama_kategori FROM kategori';
$result2 = mysqli_query($connection, $query2)

?>

<?php require_once '../components/header.php' ?>
<?php require_once '../components/navbar.php' ?>
<?php require_once "../components/sidenav.php" ?>

<main class="main" id="main">
  <div class="pagetitle">
    <h1>Data Kategori</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Data Kategori</li>
      </ol>
    </nav>
  </div>

  <section class="section">
    <!-- Table list data kategori produk -->

    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="card-title">Kategori Produk</h5>

          <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#tambahkategori">
            <i class="fa fa-plus"></i>
            Tambah kategori
          </button>
          <!-- Modal -->
          <div class="modal fade" id="tambahkategori" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Kategori</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <form method="POST" action="../process/proses_form_kategori.php">
                    <div class="mb-3">
                      <label class="form-label">Nama Kategori</label>
                      <input type="text" class="form-control" placeholder="masukan nama kategori" name="nama_kategori">
                    </div>

                    <div class="d-flex justify-content-end">
                      <button type="submit" class="btn btn-sm btn-primary me-1">
                        <i class="bi bi-check-lg"></i>
                        Simpan
                      </button>
                      <button type="button" class="btn  btn-sm btn-warning" data-bs-dismiss="modal">
                        <i class="bi bi-x-lg"></i>
                        Batal
                      </button>
                    </div>
                  </form>

                </div>
              </div>
            </div>
          </div>

        </div>
        <table class="table table-responsive table-bordered border-dark text-center">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama kategori</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if ($result2 && mysqli_num_rows($result2) > 0) {
              while ($row = mysqli_fetch_assoc($result2)) {
                $id = $row['id_kategori'];
                $kategori = $row['nama_kategori'];
                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++;
                echo "<td>$kategori</td>";
                echo "<td class='text-center'>";
                echo "<button class='btn btn-sm btn-danger' onclick='deleteCategory($id)'>";
                echo "<i class='fa fa-trash me-1'></i>";
                echo "Hapus";
                echo "</button>";
                echo "</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='3'>No data found</td></tr>";
            }
            ?>

          </tbody>
        </table>
      </div>
    </div>

  </section>
</main>
<script>
  function deleteCategory(id) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "../process/proses_form_kategori.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
      if (xhr.readyState === 4 && xhr.status === 200) {
        // Handle the response
      }
    };
    xhr.send("delete_id=" + id);
    location.reload()
  }
</script>

<?php require_once '../components/footer.php' ?>