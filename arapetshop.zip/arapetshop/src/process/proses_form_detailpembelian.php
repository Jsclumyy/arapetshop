<?php
session_start();
require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // isian untuk tabel detail_pembelian diisi pada halaman detail penjualan
  $id_barang = $_POST['id_barang'];
  // $jumlah_detpembelian = $_POST['jumlah_detpembelian'];
  $harga_detpembelian = $_POST['harga_detpembelian'];
  $id_pembelian = $_POST['id_pembelian'];
  $total_detpembelian = $_POST['total_detpembelian'];

  $connection = mysqli_connect($servername, $username, $password, $database);

  // Ambil harga_barang dari tabel barang berdasarkan id_barang
  $ambilHargaQuery = "SELECT id_barang, harga_barang FROM barang WHERE id_barang = ?";
  $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
  mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
  mysqli_stmt_execute($stmtAmbilHarga);
  $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
  $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);

  // ambil nama_barang dari tabel barang berdasarkan id_barang
  $ambilNamaQuery = "SELECT nama_barang FROM barang WHERE id_barang = ?";
  $stmtAmbilNama = mysqli_prepare($connection, $ambilNamaQuery);
  mysqli_stmt_bind_param($stmtAmbilNama, "i", $id_barang);
  mysqli_stmt_execute($stmtAmbilNama);
  $resultAmbilNama = mysqli_stmt_get_result($stmtAmbilNama);
  $rowAmbilNama = mysqli_fetch_assoc($resultAmbilNama);

  // ambil harga_pembelian dari tabel pembelian berdasarkan id_pembelian
  $ambilHargaBeli = "SELECT harga_pembelian FROM pembelian WHERE id_pembelian = ?";
  $stmtAmbilHargaBeli = mysqli_prepare($connection, $ambilHargaBeli);
  mysqli_stmt_bind_param($stmtAmbilHargaBeli, "i", $id_pembelian);
  mysqli_stmt_execute($stmtAmbilHargaBeli);
  $resultAmbilHargaBeli = mysqli_stmt_get_result($stmtAmbilHargaBeli);
  $rowAmbilHargaBeli = mysqli_fetch_assoc($resultAmbilHargaBeli);
  $harga_pembelian = $rowAmbilHargaBeli['harga_pembelian'];
  if (!empty($harga_detpembelian)) {
    // Jika harga_detpembelian diisi, update harga_pembelian pada tabel pembelian
    $harga_pembelian = $harga_detpembelian * $total_detpembelian;
    // Mengupdate harga_pembelian pada tabel pembelian
    $updateHargaBeliQuery = "UPDATE pembelian SET harga_pembelian = ? WHERE id_pembelian = ?";
    $stmtUpdateHargaBeli = mysqli_prepare($connection, $updateHargaBeliQuery);
    mysqli_stmt_bind_param($stmtUpdateHargaBeli, "di", $harga_pembelian, $id_pembelian);
    mysqli_stmt_execute($stmtUpdateHargaBeli);
  }

  // Calculate jumlah_detpembelian
  $jumlah_detpembelian = $total_detpembelian * $harga_detpembelian;

  // Insert data ke tabel detail_pembelian
  $insertDetailQuery = "INSERT INTO detail_pembelian (id_barang, jumlah_detpembelian, harga_detpembelian, total_detpembelian, id_pembelian) VALUES (?, ?, ?, ?, ?)";
  $stmtInsertDetail = mysqli_prepare($connection, $insertDetailQuery);
  mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpembelian, $harga_detpembelian, $total_detpembelian, $id_pembelian);

  // Update harga_barang pada tabel barang
  $updateHargaBarangQuery = "UPDATE barang SET harga_barang = ? WHERE id_barang = ?";
  $stmtUpdateHargaBarang = mysqli_prepare($connection, $updateHargaBarangQuery);
  mysqli_stmt_bind_param($stmtUpdateHargaBarang, "di", $harga_detpembelian, $id_barang);
  mysqli_stmt_execute($stmtUpdateHargaBarang);

  // jika data sudah masuk ke detail_pembelian, update table kartu stok
  if (mysqli_stmt_execute($stmtInsertDetail)) {
    echo "Data inserted successfully";

    // Fetch the id_barang from the inserted row in detail_pembelian
    $insertedId = $id_barang;
    $jumlah_final = $total_detpembelian;
    $tanggal = date('Y-m-d');

    // Fetch the kode_barang based on id_barang
    $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
    $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
    mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
    mysqli_stmt_execute($stmtAmbilKode);
    $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
    $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
    $kode_barang = $rowAmbilKode['kode_barang'];

    // Insert the values into the table kartu_gudang
    $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, kode_barang, total_detpembelian, jumlah_final, tanggal) VALUES (?, ?, ?, ?, ?)";
    $stmtKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
    mysqli_stmt_bind_param($stmtKartuGudang, "isiis", $insertedId, $kode_barang, $total_detpembelian, $jumlah_final, $tanggal);

    if (mysqli_stmt_execute($stmtKartuGudang)) {
      echo "Data inserted into kartu_gudang successfully";
    } else {
      echo "Error inserting data into kartu_gudang: " . mysqli_error($connection);
    }
  } else {
    echo "Failed to insert data";
  }

  mysqli_close($connection);
  mysqli_stmt_close($stmtInsertDetail);

  header('Location: ../views/detail_pembelian.php?id_pembelian=' . $id_pembelian . '');
}
