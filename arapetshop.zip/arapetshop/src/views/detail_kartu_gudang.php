<?php
// detail_page.php

require_once "../../koneksi.php"; // Sesuaikan dengan path ke file koneksi
$connection = mysqli_connect($servername, $username, $password, $database);

if (!$connection) {
  die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id_barang'])) {
  $id_barang = $_GET['id_barang'];

  $query = "SELECT kg.kode_barang, kg.total_detpembelian, kg.total_detpenjualan, kg.jumlah_final, kg.tanggal, b.nama_barang
  FROM kartu_gudang kg
  JOIN barang b ON kg.id_barang = b.id_barang
  WHERE kg.id_barang = '$id_barang'";


  $result = mysqli_query($connection, $query);

  if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $kode_barang = $row['kode_barang'];
    $nama_barang = $row['nama_barang'];
    $totalPembelian = $row['total_detpembelian'];
    $totalPenjualan = $row['total_detpenjualan'];
    $jumlahFinal = $row['jumlah_final'];
    $tanggal = $row['tanggal'];
  } else {
    echo "Data not found.";
    exit;
  }
} else {
  echo "Invalid request.";
  exit;
}

?>

<?php require_once '../components/header.php' ?>
<?php require_once '../components/navbar.php' ?>
<?php require_once "../components/sidenav.php" ?>
<style>
  @media print {
    .header fixed-top d-flex align-items-center {
      display: none !important;
    }
  }
</style>

<main class="main" id="main">
  <div class="pagetitle">
    <h1>Data Kartu Gudang</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        <li class="breadcrumb-item">Table Kartu Gudang</li>
        <li class="breadcrumb-item active">Detail</li>
      </ol>
    </nav>
  </div>
  <section class="section">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mt-1">
          <h5 class="card-title">Kartu Gudang </h5>
          <div>
            <a href="javascript:history.back()" class="btn btn-primary btn-sm">
              <i class="fa fa-arrow-left"></i>
              Kembali
            </a>
            <button class="btn btn-sm btn-success" id="printButton">
              <i class="bi bi-printer"></i>
              Cetak
            </button>
          </div>
        </div>
        <hr>
        <h6 class="font-bold"> Kode Barang: <?php echo $kode_barang ?> </h6>
        <h6 class="font-bold">Nama Barang: <?php echo $nama_barang ?> </h6>
        <table class="table table-responsive table-bordered border-dark">
          <thead class="text-center">
            <th>No.</th>
            <th>Tanggal</th>
            <th>Pembelian</th>
            <th>Penjualan</th>
            <th>Saldo</th>
          </thead>
          <tbody class="text-center">
            <?php
            $query = "SELECT kg.kode_barang, kg.total_detpembelian, kg.total_detpenjualan, kg.jumlah_final, kg.tanggal, b.nama_barang
        FROM kartu_gudang kg
        JOIN barang b ON kg.id_barang = b.id_barang
        WHERE kg.id_barang = '$id_barang'";

            $result = mysqli_query($connection, $query);

            if (!$result) {
              die("Query failed: " . mysqli_error($connection));
            }

            if ($result && mysqli_num_rows($result) > 0) {
              $rowNumber = 1;
              while ($row = mysqli_fetch_assoc($result)) {
                $kode_barang = $row['kode_barang'];
                $nama_barang = $row['nama_barang'];  // Fetch the nama_barang from the joined table
                $totalPembelian = $row['total_detpembelian'];
                $totalPenjualan = $row['total_detpenjualan'];
                $jumlahFinal = $row['jumlah_final'];
                $tanggal = $row['tanggal'];
                echo "<tr>";
                echo "<td>" . $rowNumber . "</td>";
                echo "<td>" . $tanggal . "</td>";
                echo "<td>" . ($totalPembelian !== null ? $totalPembelian : 0) . "</td>";
                echo "<td>" . ($totalPenjualan !== null ? $totalPenjualan : 0) . "</td>";
                echo "<td>" . $jumlahFinal . "</td>";
                echo "</tr>";

                $rowNumber++;
              }
            } else {
              echo "<tr><td colspan='6'>Tidak ada data</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
    </div>


  </section>
</main>
<script>
  // Menangkap tombol cetak
  const printButton = document.getElementById('printButton');

  // Menambahkan event listener untuk tombol cetak
  printButton.addEventListener('click', function() {
    // Memanggil fungsi bawaan browser untuk mencetak
    window.print();
  });
</script>



<?php require_once '../components/footer.php' ?>