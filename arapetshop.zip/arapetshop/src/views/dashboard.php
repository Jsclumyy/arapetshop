<?php
session_start();

require_once "../../functions.php";
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}

if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

$connection = mysqli_connect($servername, $username, $password, $database);

// mendapatkan data total barang dari database
$query_total_barang = "SELECT COUNT(*) AS total_barang FROM barang";
$result_total_barang = mysqli_query($connection, $query_total_barang);
// fungsi associative array untuk mengambil data total barang
$row_total_barang = mysqli_fetch_assoc($result_total_barang);
$totalBarang = $row_total_barang['total_barang'];

// menampilkan data total kategori dari database
$query_total_kategori = "SELECT COUNT(*) AS total_kategori FROM kategori";
$result_total_kategori = mysqli_query($connection, $query_total_kategori);
// fungsi associative array untuk mengambil data total kategori
$row_total_kategori = mysqli_fetch_assoc($result_total_kategori);
$totalKategori = $row_total_kategori['total_kategori'];

// menampilkan data total detail pembelian dari database
$query_total_barang_masuk = "SELECT COUNT(*) AS detail_pembelian FROM detail_pembelian";
$result_total_barang_masuk = mysqli_query($connection, $query_total_barang_masuk);
// fungsi associative array untuk mengambil data total detail pembelian
$row_total_barang_masuk = mysqli_fetch_assoc($result_total_barang_masuk);
$totalBarangMasuk = $row_total_barang_masuk['detail_pembelian'];

// menampilkan data total detail penjualan dari database
$query_total_barang_keluar = "SELECT COUNT(*) AS detail_penjualan FROM detail_penjualan";
$result_total_barang_keluar = mysqli_query($connection, $query_total_barang_keluar);
// fungsi associative array untuk mengambil data total detail penjualan
$row_total_barang_keluar = mysqli_fetch_assoc($result_total_barang_keluar);
$totalBarangKeluar = $row_total_barang_keluar['detail_penjualan'];



// Query untuk mengambil data jumlah barang masuk per tanggal
$query_total_barang_masuk_per_tanggal = "SELECT p.tanggal_pembelian, SUM(d.total_detpembelian) AS total_barang_masuk_per_tanggal
  FROM pembelian p
  JOIN detail_pembelian d ON p.id_pembelian = d.id_pembelian
  GROUP BY p.tanggal_pembelian";

$result_total_barang_masuk_per_tanggal = mysqli_query($connection, $query_total_barang_masuk_per_tanggal);
$data_total_barang_masuk_per_tanggal = array();
$tanggal_masuk_labels = array();
while ($row = mysqli_fetch_assoc($result_total_barang_masuk_per_tanggal)) {
  $data_total_barang_masuk_per_tanggal[] = $row['total_barang_masuk_per_tanggal'];
  $tanggal_masuk_labels[] = $row['tanggal_pembelian'];
}


// Query untuk mengambil data jumlah barang keluar per tanggal
$query_total_barang_keluar_per_tanggal = "SELECT p.tanggal_penjualan, SUM(d.total_detpenjualan) AS total_barang_keluar_per_tanggal 
FROM penjualan p 
JOIN detail_penjualan d ON p.id_penjualan = d.id_penjualan
GROUP BY p.tanggal_penjualan";

$result_total_barang_keluar_per_tanggal = mysqli_query($connection, $query_total_barang_keluar_per_tanggal);
$data_total_barang_keluar_per_tanggal = array();
$tanggal_keluar_labels = array();
while ($row = mysqli_fetch_assoc($result_total_barang_keluar_per_tanggal)) {
  $data_total_barang_keluar_per_tanggal[] = $row['total_barang_keluar_per_tanggal'];
  $tanggal_keluar_labels[] = $row['tanggal_penjualan'];
}
?>

<?php require_once '../components/header.php' ?>
<?php require_once "../components/navbar.php"; ?>
<?php require_once "../components/sidenav.php" ?>


<!-- content -->
<main id="main" class="main">

  <div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../views/Dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section dashboard">
    <div class="row">
      <div class="col">
        <!-- barang masuk -->
        <div class="card info-card sales-card">
          <div class="card-body">
            <h5 class="card-title">Pembelian <span>| Today</span></h5>
            <div class="d-flex align-items-center">
              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                <i class="bi bi-box-arrow-in-right"></i>
              </div>
              <div class="ps-3">
                <?php echo "<h6>$totalBarangMasuk</h6>" ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col">
        <!-- barang keluar -->
        <div class="card info-card revenue-card">
          <div class="card-body">
            <h5 class="card-title">Penjualan <span>| Today</span></h5>
            <div class="d-flex align-items-center">
              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                <i class="bi bi-box-arrow-right"></i>
              </div>
              <div class="ps-3">
                <?php echo "<h6>$totalBarangKeluar</h6>" ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col">
        <!-- total barang -->
        <div class="card info-card sales-card">
          <div class="card-body">
            <h5 class="card-title">Total Barang <span>| Today</span></h5>
            <div class="d-flex align-items-center">
              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                <i class="bi bi-cart2"></i>
              </div>
              <div class="ps-3">
                <?php echo "<h6>$totalBarang</h6>" ?>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col">
        <!-- total kategori -->
        <div class="card info-card customers-card">
          <div class="card-body">
            <h5 class="card-title">Total Kategori <span>| Today</span> </h5>
            <div class="d-flex align-items-center">
              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                <i class="bi bi-clipboard"></i>
              </div>
              <div class="ps-3">
                <?php echo "<h6>$totalKategori</h6>" ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="col">
        <!-- grafik pembelian -->
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Grafik Pembelian <span>| per bulan</span></h5>

            <!-- Bar Chart -->
            <canvas id="barChartMasuk" style="max-height: 400px;"></canvas>
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                const dataTotalBarangMasukPerTanggal = <?php echo json_encode($data_total_barang_masuk_per_tanggal); ?>;
                const tanggalLabels = <?php echo json_encode($tanggal_masuk_labels); ?>;
                new Chart(document.querySelector('#barChartMasuk'), {
                  type: 'bar',
                  data: {
                    labels: tanggalLabels,
                    datasets: [{
                      label: 'Barang Masuk',
                      data: dataTotalBarangMasukPerTanggal,
                      backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                      ],
                      borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                      ],
                      borderWidth: 1
                    }]
                  },
                  options: {
                    scales: {
                      y: {
                        beginAtZero: true
                      }
                    }
                  }
                });
              });
            </script>
            <!-- End Bar CHart -->

          </div>
        </div>
      </div>
      <div class="col">
        <!-- grafik penjualan -->
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Grafik Penjualan <span>| per bulan</span></h5>

            <!-- Bar Chart -->
            <canvas id="barChartKeluar" style="max-height: 400px;"></canvas>
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                const dataTotalBarangKeluarPerTanggal = <?php echo json_encode($data_total_barang_keluar_per_tanggal); ?>;
                const tanggalLabels = <?php echo json_encode($tanggal_keluar_labels); ?>;
                new Chart(document.querySelector('#barChartKeluar'), {
                  type: 'bar',
                  data: {
                    labels: tanggalLabels,
                    datasets: [{
                      label: 'Barang Keluar',
                      data: dataTotalBarangKeluarPerTanggal,
                      backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 205, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(201, 203, 207, 0.2)'
                      ],
                      borderColor: [
                        'rgb(255, 99, 132)',
                        'rgb(255, 159, 64)',
                        'rgb(255, 205, 86)',
                        'rgb(75, 192, 192)',
                        'rgb(54, 162, 235)',
                        'rgb(153, 102, 255)',
                        'rgb(201, 203, 207)'
                      ],
                      borderWidth: 1
                    }]
                  },
                  options: {
                    scales: {
                      y: {
                        beginAtZero: true
                      }
                    }
                  }
                });
              });
            </script>
            <!-- End Bar CHart -->

          </div>
        </div>

      </div>
    </div>

    </div>
  </section>

</main><!-- End #main -->

<?php require_once "../components/footer.php" ?>