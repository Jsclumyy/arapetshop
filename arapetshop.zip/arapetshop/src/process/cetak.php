<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Ara Petshop</title>
  <style>
    /* Example style for table borders */
    table {
      border-collapse: collapse;
      width: 100%;
    }

    th,
    td {
      border: 1px solid black;
      padding: 8px;
      text-align: center;
    }
  </style>

</head>

<body>
  <center>



    <?php
    // detail_page.php

    require_once "../../koneksi.php"; // Sesuaikan dengan path ke file koneksi
    $connection = mysqli_connect($servername, $username, $password, $database);

    if (!$connection) {
      die("Connection failed: " . mysqli_connect_error());
    }

    if (isset($_GET['id_barang'])) {
      $id_barang = $_GET['id_barang'];

      $query = "SELECT kg.kode_barang, kg.total_detpembelian, kg.total_detpenjualan, kg.jumlah_final, kg.tanggal, b.nama_barang
  FROM kartu_gudang kg
  JOIN barang b ON kg.id_barang = b.id_barang
  WHERE kg.id_barang = '$id_barang'";


      $result = mysqli_query($connection, $query);

      if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $kode_barang = $row['kode_barang'];
        $nama_barang = $row['nama_barang'];
        $totalPembelian = $row['total_detpembelian'];
        $totalPenjualan = $row['total_detpenjualan'];
        $jumlahFinal = $row['jumlah_final'];
        $tanggal = $row['tanggal'];
      } else {
        echo "Data not found.";
        exit;
      }
    } else {
      echo "Invalid request.";
      exit;
    }

    ?>

    <table class="table table-responsive table-bordered border-dark">
      <thead class="text-center">
        <tr>
          <th rowspan="2">Tanggal</th>
          <th rowspan="2">Nama Barang</th>
          <th colspan="3">Pembelian</th>
          <th colspan="3">Penjualan</th>
          <th colspan="3">Saldo</th>
        </tr>
        <tr>
          <th>Qty</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Qty</th>
          <th>Harga</th>
          <th>Jumlah</th>
          <th>Qty</th>
          <th>Harga</th>
          <th>Jumlah</th>
        </tr>
      </thead>
      <tbody class="text-center">
        <?php
        if ($result && mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
            $tanggal = $row['tanggal_ks'] ?? 0;
            $total_in_ks = $row['total_in_ks'] ?? 0;
            $total_out_ks = $row['total_out_ks'] ?? 0;
            $total_final_ks = $row['total_final_ks'] ?? 0;
            $nama_barang = $row['nama_barang'] ?? 0;
            echo "<tr>";
            echo "<td>$tanggal</td>";
            echo "<td>$nama_barang</td>";
            echo '<td>' . $total_in_ks . '</td>';
            echo '<td> Rp ' . number_format($row['harga_in_ks'] ?? 0, 0, ',', '.') . '</td>';
            echo '<td> Rp ' . number_format($row['jumlah_in_ks'] ?? 0, 0, ',', '.') . '</td>';
            echo '<td>' . $total_out_ks . '</td>';
            echo '<td> Rp ' . number_format($row['harga_out_ks'] ?? 0, 0, ',', '.') . '</td>';
            echo '<td> Rp ' . number_format($row['jumlah_out_ks'] ?? 0, 0, ',', '.') . '</td>';
            echo '<td>' . $total_final_ks . '</td>';
            echo '<td> Rp ' . number_format($row['harga_final_ks'] ?? 0, 0, ',', '.') . '</td>';
            echo '<td> Rp ' . number_format($row['jumlah_final_ks'] ?? 0, 0, ',', '.') . '</td>';
          }
        } else {
          echo "<tr><td colspan='10'>Tidak ada data</td></tr>";
        }
        ?>
      </tbody>

    </table>

  </center>
  <script>
    window.print()
  </script>
</body>

</html>