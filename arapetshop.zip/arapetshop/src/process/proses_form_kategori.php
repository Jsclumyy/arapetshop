<?php
session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}

// function for add data into database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nama_kategori'])) {
  $connection = mysqli_connect($servername, $username, $password, $database);
  $nama_kategori = $_POST['nama_kategori'];
  $insertQueryKategori = "INSERT INTO kategori (nama_kategori) VALUES ('$nama_kategori')";
  mysqli_query($connection, $insertQueryKategori);
}

// Function to delete the data
function deleteData($id, $connection)
{
  // query menghapus data
  $query = "DELETE FROM kategori WHERE id_kategori = ?";
  $stmt = mysqli_prepare($connection, $query);
  mysqli_stmt_bind_param($stmt, "i", $id);
  mysqli_stmt_execute($stmt);
  // cek apakah data sudah berhasil dihapus?
  if (mysqli_stmt_affected_rows($stmt) > 0) {
    echo "Data with ID: $id successfully deleted";
  } else {
    echo "Failed to delete data with ID: $id";
  }
  // hentikan statement
  mysqli_stmt_close($stmt);
}

// cek function delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = $_POST['delete_id'];
  $connection = mysqli_connect($servername, $username, $password, $database);
  // Check if the connection is successful
  if (!$connection) {
    echo "Failed to connect to the database: " . mysqli_connect_error();
    exit;
  }
  deleteData($id, $connection);
  mysqli_close($connection);
  exit;
}

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);

header("Location: ../views/kategori.php");
exit;
