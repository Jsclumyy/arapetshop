<?php

session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}


if (!isset($_SESSION['user'])) {
  header('location: ../../index.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // retrive the form inputs
  // $no_transaksi = $_POST['notransaksi_pembelian'];
  $tanggal_pembelian = $_POST['tanggal_pembelian'];
  // $id_supplier = $_POST['id_supplier'];
  // $harga_pembelian = $_POST['harga_pembelian'];
  $connection = mysqli_connect($servername, $username, $password, $database);
  $insertQuery = "INSERT INTO pembelian ( tanggal_pembelian) VALUES ( ?)";
  $stmt = mysqli_prepare($connection, $insertQuery);
  mysqli_stmt_bind_param($stmt, "s",  $tanggal_pembelian);
  if (mysqli_stmt_execute($stmt)) {
    echo "Data inserted successfully";
  } else {
    echo "Failed to insert data";
  }
  mysqli_stmt_close($stmt);
  mysqli_close($connection);
  header('Location: ../views/pembelian.php');
}
