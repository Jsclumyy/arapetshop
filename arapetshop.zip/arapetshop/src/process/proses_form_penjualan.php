<?php

session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}

if (!isset($_SESSION['user'])) {
  header('location: ../../index.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // $kode_penjualan = $_POST['kode_penjualan'];
  $tanggal_penjualan = $_POST['tanggal_penjualan'];
  // $harga_penjualan = $_POST['harga_penjualan'];

  $connection = mysqli_connect($servername, $username, $password, $database);

  $insertQuery = "INSERT INTO penjualan ( tanggal_penjualan) 
                  VALUES ( ?)";

  $stmt = mysqli_prepare($connection, $insertQuery);

  mysqli_stmt_bind_param($stmt, "s", $tanggal_penjualan);

  if (mysqli_stmt_execute($stmt)) {
    echo "Data inserted successfully";
  } else {
    echo "Failed to insert data";
  }

  mysqli_stmt_close($stmt);
  mysqli_close($connection);

  header('Location: ../views/penjualan.php');
}
