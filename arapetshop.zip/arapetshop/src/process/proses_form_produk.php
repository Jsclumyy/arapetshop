<?php
session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../../index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the form inputs
    $deskripsi_barang = $_POST['deskripsi_barang'];
    $nama_barang = $_POST['nama_barang'];
    $id_kategori = $_POST['id_kategori'];

    // Establish database connection
    $connection = mysqli_connect($servername, $username, $password, $database);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Query to get the maximum existing value of kode_barang
    $maxKodeQuery = "SELECT MAX(CAST(SUBSTRING(kode_barang, 4) AS UNSIGNED)) AS max_kode FROM barang";
    $result = mysqli_query($connection, $maxKodeQuery);

    if (!$result) {
        die("Query failed: " . mysqli_error($connection));
    }

    $maxKodeRow = mysqli_fetch_assoc($result);
    $maxKodeValue = $maxKodeRow['max_kode'];
    $nextKodeValue = $maxKodeValue + 1;

    // Format the next value to 'BRG01', 'BRG02', etc.
    $formattedNextKode = 'BRG' . str_pad($nextKodeValue, 2, '0', STR_PAD_LEFT);

    // Prepare the insert query
    $insertQuery = "INSERT INTO barang (deskripsi_barang, nama_barang, kode_barang, id_kategori) VALUES (?, ?, ?, ?)";

    // Prepare the statement
    $stmt = mysqli_prepare($connection, $insertQuery);

    // Bind the parameters
    mysqli_stmt_bind_param($stmt, "sssi", $deskripsi_barang, $nama_barang, $formattedNextKode, $id_kategori);

    // Execute the statement
    if (mysqli_stmt_execute($stmt)) {
        // Data insertion successful
        echo "Data inserted successfully";
    } else {
        // Data insertion failed
        echo "Failed to insert data";
    }

    // Close the statement and connection
    mysqli_stmt_close($stmt);
    mysqli_close($connection);

    header('Location: ../views/produk.php');
}
