<?php
session_start();

require_once "../../functions.php"; // Add this line to include the functions.php file
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}
if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

// get data pembelian
$connection = mysqli_connect($servername, $username, $password, $database);
$query = "SELECT pembelian.id_pembelian, pembelian.notransaksi_pembelian, pembelian.tanggal_pembelian,  pembelian.id_supplier, pembelian.harga_pembelian
FROM pembelian ";
$result = mysqli_query($connection, $query);


?>

<?php require_once '../components/header.php' ?>
<?php require_once "../components/navbar.php"; ?>
<?php require_once "../components/sidenav.php" ?>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>Pembelian</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="Dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Pembelian</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="card-title">Data Pembelian </h5>
          <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#tambahpembelian">
            <i class="fa fa-plus"></i>
            Tambah Data Pembelian
          </button>

        </div>
        <hr>
        <table class="table table-responsive table-bordered border-dark text-center">
          <thead>
            <tr>
              <th>Nomor</th>
              <!-- <th>No Transaksi</th> -->
              <th>Tanggal Pembelian</th>
              <!-- <th>Nama Supplier</th> -->
              <th>Jumlah Harga Beli</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 01;
            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {

                $id = $row['id_pembelian'];
                // $no_transaksi = $row['notransaksi_pembelian'];
                $tanggal = $row['tanggal_pembelian'];
                $harga = $row['harga_pembelian'];
                // $supplier_id = $row['id_supplier']; // Renamed for clarity

                // Fetch the supplier name based on the supplier_id


                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++;
                echo "<td>$tanggal</td>";
                // echo "<td>$supplier_name</td>";
                echo "<td> Rp." . ($harga !== null ? number_format($harga, 0, ',', '.') : "0") . "</td>";
                echo "<td class='text-center'>";
                echo "<div>";
                echo "<a href='detail_pembelian.php?id_pembelian=$id'  class='btn btn-sm btn-primary me-1 mb-1'>";
                echo "<i class='fa fa-search'></i>";
                echo " Lihat Detail";
                echo "</a>";
                echo "</div>";
                echo "</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='4'>No data found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
    <div class="modal fade" id="tambahpembelian" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h1 class="modal-title fs-5">Tambah Data Pembelian</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body">
            <form action="../process/proses_form_pembelian.php" method="POST">
              <!-- <div class="mb-3">
                  <label class="form-label">Nomor Transaksi</label>
                  <input type="number" class="form-control" placeholder="0001" name="notransaksi_pembelian">
                </div> -->
              <div class="mb-3">
                <label class="form-label">Tanggal Pembelian</label>
                <input type="date" class="form-control" name="tanggal_pembelian">
              </div>
              <!-- <div class="mb-3">
                  <label class="form-label">PIlih Supplier</label>
                  <select class="form-select" id="id_supplier" name="id_supplier">
                    <?php
                    $connection = mysqli_connect($servername, $username, $password, $database);
                    if (!$connection) {
                      die("Koneksi gagal: " . mysqli_connect_error());
                    }
                    $query = "SELECT * FROM supplier";
                    $result = mysqli_query($connection, $query);
                    while ($row = mysqli_fetch_array($result)) {
                      echo "<option value='" . $row['id_supplier'] . "'>" . $row['nama_supplier'] . "</option>";
                    }
                    mysqli_close($connection);
                    ?>
                  </select>
                </div> -->
              <!-- <div class="mb-3">
                  <label class="form-label">Total Harga Beli</label>
                  <input type="number" class="form-control" name="harga_pembelian">
                </div> -->
              <div class="d-flex justify-content-end">
                <button type="submit" class="btn btn-sm btn-primary me-1">
                  <i class="bi bi-check-lg"></i>
                  Simpan
                </button>
                <button type="button" class="btn btn-secondary btn-sm btn-warning" data-bs-dismiss="modal">
                  <i class="bi bi-x-lg"></i>
                  Batal
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>
<?php require_once "../components/footer.php"; ?>