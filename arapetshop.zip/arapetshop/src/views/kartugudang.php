<?php
session_start();
require_once "../../functions.php";
require_once "../../koneksi.php";

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}
if (isset($_POST['logout'])) {
  logout();
}
?>

<?php require_once '../components/header.php' ?>
<?php require_once '../components/navbar.php' ?>
<?php require_once "../components/sidenav.php" ?>

<main class="main" id="main">
  <div class="pagetitle">
    <h1>Data Kartu Gudang</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Table Kartu Gudang</li>
      </ol>
    </nav>
  </div>


  <section class="section">

    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mt-1">
          <h5 class="card-title">Kartu Gudang Persediaan Barang</h5>
        </div>
        <hr>
        <table class="table table-responsive table-bordered border-dark">
          <thead class="text-center">
            <th>No.</th>
            <th>Kode Barang</th>
            <th>Nama Barang</th>
            <th>Aksi</th>

          </thead>
          <tbody class="text-center">
            <?php
            $connection = mysqli_connect($servername, $username, $password, $database);

            if (!$connection) {
              die("Connection failed: " . mysqli_connect_error());
            }

            $query = 'SELECT kode_barang, id_barang, nama_barang FROM barang';
            $result = mysqli_query($connection, $query);

            if (!$result) {
              die("Query failed: " . mysqli_error($connection));
            }

            if ($result && mysqli_num_rows($result) > 0) {
              $rowNumber = 1;
              while ($row = mysqli_fetch_assoc($result)) {
                $kode_barang = $row['kode_barang'];
                $nama_barang = $row['nama_barang'];
                echo "<tr>";
                echo "<td>" . $rowNumber . "</td>";
                echo "<td>" . $kode_barang . "</td>";
                echo "<td>" . $nama_barang . "</td>";
                echo "<td>";
                echo "<a href='detail_kartu_gudang.php?id_barang=" . $row['id_barang'] . "' class='btn btn-sm btn-primary'>
                <i class='fa fa-magnifying-glass'></i>
                Detail
                </a>";
                echo "</td>";
                echo "</tr>";
                $rowNumber++;
              }
            } else {
              echo "<tr><td colspan='6'>Tidak ada data</td></tr>";
            }
            ?>
          </tbody>

        </table>

      </div>
    </div>

  </section>


</main>

<?php require_once '../components/footer.php' ?>