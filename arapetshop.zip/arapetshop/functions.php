<?php

// fungsi untuk login
function login($conn, $name, $password)
{
  // periksa data pada tabel user
  $query = "SELECT * FROM user WHERE name = :name AND password = :password";

  // statement untuk login
  $statement = $conn->prepare($query);
  $statement->bindParam(':name', $name);
  $statement->bindParam(':password', $password);
  $statement->execute();

  // dapatkan data user 
  $user = $statement->fetch(PDO::FETCH_ASSOC);

  // periksa apakah data user tersedia
  if ($user) {
    // mulai session dan simpan informasi user
    $_SESSION['user'] = $user;
    // Alihkan ke halaman dashboard setelah berhasil login
    header("Location: src/views/Dashboard.php?login=success");
    exit;
  } else {
    // jika login tidak berhasil, tampilkan pesan error
    $error = "Invalid email or password";
    return $error;
  }
}

// fungsi untuk logout
function logout()
{
  // mulai session
  session_start();
  // hapus semua session user
  $_SESSION = array();
  // hapus session
  session_destroy();
  // alihkan ke halaman login atau index.php
  header("Location: ../../index.php");
  exit;
}
