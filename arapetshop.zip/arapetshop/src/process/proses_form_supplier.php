<?php
session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}

// function for adding data to the supplier table
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['nama_supplier'], $_POST['alamat_supplier'], $_POST['telp_supplier'])) {
  $connection = mysqli_connect($servername, $username, $password, $database);
  $nama_supplier = $_POST['nama_supplier'];
  $alamat_supplier = $_POST['alamat_supplier'];
  $telp_supplier = $_POST['telp_supplier'];
  $insertQuerySupplier = "INSERT INTO supplier (nama_supplier, alamat_supplier, telp_supplier) VALUES ('$nama_supplier', '$alamat_supplier', '$telp_supplier')";
  mysqli_query($connection, $insertQuerySupplier);
}

// function to delete the supplier data
function deleteData($id, $connection)
{
  $query = "DELETE FROM supplier WHERE supplier_id = ?";
  $stmt = mysqli_prepare($connection, $query);
  mysqli_stmt_bind_param($stmt, "i", $id);
  mysqli_stmt_execute($stmt);
  mysqli_stmt_close($stmt);
}


// cek function delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  $id = $_POST['delete_id'];
  $connection = mysqli_connect($servername, $username, $password, $database);
  deleteData($id, $connection);
  mysqli_close($connection);
}

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);

header("Location: ../views/supplier.php");
exit;
