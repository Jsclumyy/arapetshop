<?php
session_start();

require_once "../../functions.php"; // Add this line to include the functions.php file
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}
if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

$id_penjualan = $_GET['id_penjualan'];
$connection = mysqli_connect($servername, $username, $password, $database);
$query = "SELECT 
barang.nama_barang,
detail_penjualan.id_detpenjualan,
detail_penjualan.id_barang,
detail_penjualan.total_detpenjualan,
detail_penjualan.harga_detpenjualan,
detail_penjualan.jumlah_detpenjualan,
detail_penjualan.id_penjualan
FROM detail_penjualan
JOIN barang ON detail_penjualan.id_barang = barang.id_barang
WHERE detail_penjualan.id_penjualan = $id_penjualan";
$result = mysqli_query($connection, $query);

?>

<?php require_once "../components/header.php"; ?>
<?php require_once "../components/navbar.php"; ?>
<?php require_once "../components/sidenav.php" ?>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>Detail Data Penjualan</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="Dashboard.php">Home</a></li>
        <li class="breadcrumb-item"><a href="penjualan.php">Penjualan</a></li>
        <li class="breadcrumb-item active">Detail Penjualan</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h1 class="card-title">Detail Penjualan</h1>
          <div>
            <a href="penjualan.php" class="btn btn-sm btn-primary">
              <i class="fa fa-arrow-left"></i>
              Kembali
            </a>
            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#tambahdetailpenjualan">
              <i class="fa fa-plus"></i>
              Tambah Data Detail Penjualan
            </button>
          </div>
        </div>
        <hr>
        <table class="table table-responsive table-bordered border-dark">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Barang</th>
              <th>Total Barang Terjual</th>
              <th>Harga Barang Satuan</th>
              <th>Jumlah Harga Terjual</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id_detpenjualan'];
                $nama_barang = $row['nama_barang'];
                $total_detpenjualan = $row['total_detpenjualan'];
                $harga_detpenjualan = $row['harga_detpenjualan'];
                $jumlah_detpenjualan = $row['jumlah_detpenjualan'];
                $id_penjualan = $row['id_penjualan'];

                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++;
                echo "<td>$nama_barang</td>";
                echo "<td>$total_detpenjualan</td>";
                echo "<td> Rp." . ($harga_detpenjualan !== null ? number_format($harga_detpenjualan, 0, ',', '.') : "0") . "</td>";
                echo "<td> Rp." . number_format($jumlah_detpenjualan, 0, ',', '.') . "</td>";
              }
            } else {
              echo "<tr><td colspan='5' class='text-center'>Tidak ada data</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      <modal class="modal fade" id="tambahdetailpenjualan" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5">Tambah Detail Penjualan</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form action="../process/proses_form_detailpenjualan.php" method="POST">
                <div class="mb-3">
                  <input type="hidden" name="id_penjualan" class="form-control" value="<?php echo $id_penjualan; ?>">
                </div>
                <div class="mb-3">
                  <label for="" class="form-label">Nama Barang</label>
                  <select name="id_barang" id="id_barang" class="form-select">
                    <?php
                    $connection = mysqli_connect($servername, $username, $password, $database);
                    $query = "SELECT * FROM barang";
                    $result = mysqli_query($connection, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                      $id_barang = $row['id_barang'];
                      $nama_barang = $row['nama_barang'];
                      echo "<option value='$id_barang'>$nama_barang</option>";
                    }
                    mysqli_close($connection);
                    ?>
                  </select>
                </div>
                <div class="mb-3">
                  <label for="" class="label-form">Total Barang</label>
                  <input type="number" class="form-control" placeholder="total barang terjual" name="total_detpenjualan">
                </div>
                <div class="d-flex justify-content-end">
                  <button type="submit" class="btn btn-sm btn-primary me-1">
                    <i class="bi bi-check-lg"></i>
                    Simpan
                  </button>
                  <button type="button" class="btn btn-secondary btn-sm btn-warning" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg"></i>
                    Batal
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </modal>
  </section>
</main>


<?php require_once "../components/footer.php"; ?>