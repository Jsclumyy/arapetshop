<?php
session_start();

require_once "../../functions.php"; // Add this line to include the functions.php file
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}
if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

$id_pembelian = $_GET['id_pembelian'];
$connection = mysqli_connect($servername, $username, $password, $database);
$query = "SELECT barang.nama_barang, detail_pembelian.id_detpembelian, detail_pembelian.id_barang, detail_pembelian.jumlah_detpembelian, detail_pembelian.harga_detpembelian, detail_pembelian.total_detpembelian, detail_pembelian.id_pembelian  
FROM detail_pembelian 
JOIN barang ON detail_pembelian.id_barang = barang.id_barang
WHERE detail_pembelian.id_pembelian = $id_pembelian";
$result = mysqli_query($connection, $query);


?>

<?php require_once "../components/header.php"; ?>

<?php require_once "../components/navbar.php"; ?>
<?php require_once "../components/sidenav.php" ?>
<main id="main" class="main">
  <div class="pagetitle">
    <h1>Detail Data Pembelian</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="Dashboard.php">Home</a></li>
        <li class="breadcrumb-item">Pembelian</li>
        <li class="breadcrumb-item active">Detail Pembelian</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h1 class="card-title">Detail Pembelian</h1>
          <div>
            <a href="pembelian.php" class="btn btn-sm btn-primary">
              <i class="fa fa-arrow-left"></i>
              Kembali
            </a>
            <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#tambahdetailpembelian">
              <i class="fa fa-plus"></i>
              Tambah Data Detail Pembelian
            </button>

          </div>
        </div>
        <table class="table table-responsive table-bordered border-dark">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Barang </th>
              <th>Total Barang Dibeli</th>
              <th>Harga Beli Satuan</th>
              <th>Jumlah Harga Beli</th>
              <!-- <th>detpembelian_pembelian_id</th> -->
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id_detpembelian'];
                $nama_barang = $row['nama_barang'];
                $jumlah_pembelian = $row['jumlah_detpembelian'];
                $harga_pembelian = $row['harga_detpembelian'];
                $total_pembelian = $row['total_detpembelian'];
                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++;
                echo "<td>$nama_barang</td>";
                echo "<td>$total_pembelian </td>";
                echo "<td> Rp." . number_format($harga_pembelian, 0, ',', '.') . "</td>";
                echo "<td> Rp." . number_format($jumlah_pembelian, 0, ',', '.') . "</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='4'>No data found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      <modal class="modal fade" id="tambahdetailpembelian" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5">Tambah Detail Pembelian</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <form action="../process/proses_form_detailpembelian.php" method="POST">
                <div class="mb-3">
                  <input type="hidden" name="id_pembelian" class="form-control" value="<?php echo $id_pembelian; ?>">
                </div>
                <div class="mb-3">
                  <label class="form-label">Nama Barang</label>
                  <select class="form-select" id="id_barang" name="id_barang">
                    <?php
                    $connection = mysqli_connect($servername, $username, $password, $database);
                    $query = "SELECT * FROM barang";
                    $result = mysqli_query($connection, $query);
                    while ($row = mysqli_fetch_assoc($result)) {
                      $id_barang = $row['id_barang'];
                      $nama_barang = $row['nama_barang'];
                      echo "<option value='$id_barang'>$nama_barang</option>";
                    }
                    mysqli_close($connection);
                    ?>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label">Total Barang</label>
                  <input class="form-control" type="number" placeholder="jumlah barang" name="total_detpembelian">
                </div>
                <div class="mb-3">
                  <label class="form-label">Harga Beli Satuan</label>
                  <input type="number" class="form-control" name="harga_detpembelian">
                </div>
                <!-- <div class="mb-3">
                    <label class="form-label">Jumlah Harga Beli</label>
                    <input type="number" class="form-control" name="jumlah_detpembelian">
                  </div> -->
                <div class="d-flex justify-content-end">
                  <button type="submit" class="btn btn-sm btn-primary me-1">
                    <i class="bi bi-check-lg"></i>
                    Simpan
                  </button>
                  <button type="button" class="btn btn-secondary btn-sm btn-warning" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg"></i>
                    Batal
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </modal>
    </div>

  </section>

</main><!-- End #main -->
<?php require_once "../components/footer.php"; ?>