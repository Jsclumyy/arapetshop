<?php
session_start();

require_once "../../functions.php"; // Add this line to include the functions.php file
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}
if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

// get data barang
$connection = mysqli_connect($servername, $username, $password, $database);
$query = "SELECT barang.id_barang, barang.kode_barang, barang.nama_barang, kategori.nama_kategori, barang.deskripsi_barang, barang.harga_barang, barang.id_kategori
FROM barang 
JOIN kategori ON barang.id_kategori = kategori.id_kategori";
$result = mysqli_query($connection, $query);


?>

<?php require_once '../components/header.php' ?>
<?php require_once "../components/navbar.php" ?>
<?php require_once "../components/sidenav.php" ?>

<!-- content -->

<main id="main" class="main">

  <div class="pagetitle">
    <h1>Data Produk</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="Dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Data Produk</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->


  <section class="section">
    <!-- Table list data produk -->
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="card-title">Daftar Produk</h5>
          <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#tambahproduk">
            <i class="fa fa-plus"></i>
            Tambah produk
          </button>
        </div>
        <hr class="text-dark mt-0 mb-4">
        <table class="table table-responsive table-bordered border-dark text-center">
          <thead>
            <tr>
              <th>No.</th>
              <th>Nama Produk</th>
              <th>Kode Produk</th>
              <th>Kategori Produk</th>
              <th>Harga Produk</th>
              <th>Deskripsi Barang</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1; // Inisialisasi nomor
            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $id = $row['id_barang'];
                $name = $row['nama_barang'];
                $kode = $row['kode_barang'];
                $kategori = $row['nama_kategori'];
                $harga = $row['harga_barang'];
                $deskripsi = $row['deskripsi_barang'];
                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++; // Tambahkan 1 ke nomor setelah setiap baris
                echo "<td>$name</td>";
                echo "<td>$kode</td>";
                echo "<td>$kategori</td>";
                echo "<td> Rp." .  ($harga !== null ? number_format($harga, 0, ',', '.') : "0") . "</td>";
                echo "<td>$deskripsi</td>";
                echo "<td class='text-center'>";
                echo "<div class='d-flex justify-content-between'>";
                echo "<button class='btn btn-sm btn-primary me-1 mb-1' onclick='editProduct($id)'>";
                echo "<i class='fa fa-pen'></i>";
                // echo "Edit";
                echo "</button>";
                echo "<button class='btn btn-sm btn-danger mb-1' onclick='deleteProduct($id)'>";
                echo "<i class='fa fa-trash'></i>";
                // echo "Hapus";
                echo "</button>";
                echo "</div>";
                echo "</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='4'>No data found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
      <!-- Modal -->
      <div class="modal fade" id="tambahproduk" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Produk</h1>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

              <form method="POST" action="../process/proses_form_produk.php">
                <div class="mb-3">
                  <label for="nama_barang" class="form-label">Nama Barang</label>
                  <input type="text" class="form-control" id="nama_barang" name="nama_barang">
                </div>
                <div class="mb-3">
                  <label for="deskripsi_barang" class="form-label">Deskripsi Barang</label>
                  <textarea type="text" class="form-control" id="deskripsi_barang" name="deskripsi_barang"></textarea>
                </div>
                <!-- <div class="mb-3">
                    <label for="harga_barang" class="form-label">Harga Barang</label>
                    <input type="number" class="form-control" id="harga_barang" name="harga_barang">
                  </div> -->

                <!-- <div class="mb-3">
                  <label for="kode_barang" class="form-label">Kode Barang</label>
                  <input type="text" class="form-control" id="kode_barang" name="kode_barang">
                </div> -->
                <div class="mb-3">
                  <label for="id_kategori" class="form-label">Kategori Barang</label>
                  <select class="form-select" id="id_kategori" name="id_kategori">
                    <!-- Populate the options dynamically from the 'kategori' table -->
                    <?php
                    $connection = mysqli_connect($servername, $username, $password, $database);

                    // Check if the connection is successful
                    if (!$connection) {
                      die("Connection failed: " . mysqli_connect_error());
                    }

                    // Fetch categories from 'kategori' table
                    $query = "SELECT * FROM kategori";
                    $result = mysqli_query($connection, $query);

                    // Generate the option elements
                    while ($row = mysqli_fetch_assoc($result)) {
                      $id_kategori = $row['id_kategori'];
                      $nama_kategori = $row['nama_kategori'];
                      echo "<option value='$id_kategori'>$nama_kategori</option>";
                    }

                    // Close the connection
                    mysqli_close($connection);
                    ?>
                  </select>
                </div>


                <div class="d-flex justify-content-end">
                  <button type="submit" class="btn btn-sm btn-primary me-1">
                    <i class="bi bi-check-lg"></i>
                    Simpan
                  </button>
                  <button type="button" class="btn btn-secondary btn-sm btn-warning" data-bs-dismiss="modal">
                    <i class="bi bi-x-lg"></i>
                    Batal
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>

<script>
  function editProduct(id) {
    console.log(`produk ${id} was edited`)
  }

  function deleteProduct(id) {
    console.log(`Data with id: ${id} successfully deleted`)
  }
</script>

<?php require_once '../components/footer.php' ?>