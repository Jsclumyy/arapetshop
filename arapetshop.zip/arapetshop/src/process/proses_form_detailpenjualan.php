<?php
session_start();

require_once '../../koneksi.php';
require_once '../../functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: ../../index.php');
  exit;
}

// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   //  value yang akan dikirim ke tabel detail_penjualan dari form detail_penjualan
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   // ambil harga_barang dari tabel barang berdasarkan id_barang
//   $ambilHargaQuery = "SELECT id_barang, harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   // ambil harga_penjualan dari tabel penjualan berdasarkan id_penjualan
//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     // Jika harga_detpenjualan diisi, update harga_penjualan pada tabel penjualan
//     $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;
//     // Mengupdate harga_penjualan pada tabel penjualan
//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);
//     // Menghitung jumlah_detpenjualan
//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;


//     // Check apakah sudah ada data pada tabel kartu_gudang untuk id_barang tersebut
//     $checkKartuGudangQuery = "SELECT id_barang FROM kartu_gudang WHERE id_barang = ?";
//     $stmtCheckKartuGudang = mysqli_prepare($connection, $checkKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtCheckKartuGudang, "i", $id_barang);
//     mysqli_stmt_execute($stmtCheckKartuGudang);
//     $resultCheckKartuGudang = mysqli_stmt_get_result($stmtCheckKartuGudang);

//     if ($rowCheckKartuGudang = mysqli_fetch_assoc($resultCheckKartuGudang)) {
//       // Fetch the kode_barang based on id_barang
//       $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
//       $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
//       mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
//       mysqli_stmt_execute($stmtAmbilKode);
//       $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
//       $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
//       $kode_barang = $rowAmbilKode['kode_barang'];

//       // fetch jumlah_final from kartu_gudang with same id_barang
//       $ambilJumlahFinalQuery = "SELECT jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//       $stmtAmbilJumlahFinal = mysqli_prepare($connection, $ambilJumlahFinalQuery);
//       mysqli_stmt_bind_param($stmtAmbilJumlahFinal, "i", $id_barang);
//       mysqli_stmt_execute($stmtAmbilJumlahFinal);
//       $resultAmbilJumlahFinal = mysqli_stmt_get_result($stmtAmbilJumlahFinal);
//       $rowAmbilJumlahFinal = mysqli_fetch_assoc($resultAmbilJumlahFinal);
//       $jumlah_final_barang = $rowAmbilJumlahFinal['jumlah_final'] - $total_detpenjualan;

//       // Jika sudah ada data pada kartu_gudang, insert baru dengan id_barang yang sama
//       $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, total_detpenjualan, jumlah_final, kode_barang) VALUES (?, ?, ?, ?)";
//       $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//       mysqli_stmt_bind_param($stmtInsertKartuGudang, "iiis", $id_barang, $total_detpenjualan, $jumlah_final_barang, $kode_barang);
//       mysqli_stmt_execute($stmtInsertKartuGudang);
//     }
//     // else {
//     //   // Jika belum ada data pada kartu_gudang, update atau tambah data
//     //   $updateKartuGudangQuery = "SELECT jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//     //   $stmtUpdateKartuGudang = mysqli_prepare($connection, $updateKartuGudangQuery);
//     //   mysqli_stmt_bind_param($stmtUpdateKartuGudang, "i", $id_barang);
//     //   mysqli_stmt_execute($stmtUpdateKartuGudang);
//     //   $resultUpdateKartuGudang = mysqli_stmt_get_result($stmtUpdateKartuGudang);

//     //   if ($rowUpdateKartuGudang = mysqli_fetch_assoc($resultUpdateKartuGudang)) {
//     //     $jumlah_final = $rowUpdateKartuGudang['jumlah_final'] - $total_detpenjualan;
//     //     $updateKartuGudangFinalQuery = "UPDATE kartu_gudang SET total_detpenjualan = ?, jumlah_final = ? WHERE id_barang = ?";
//     //     $stmtUpdateKartuGudangFinal = mysqli_prepare($connection, $updateKartuGudangFinalQuery);
//     //     mysqli_stmt_bind_param($stmtUpdateKartuGudangFinal, "iii", $total_detpenjualan, $jumlah_final, $id_barang);
//     //     mysqli_stmt_execute($stmtUpdateKartuGudangFinal);
//     //   } else {
//     //     // Jika tidak ada data pada kartu_gudang, insert baru
//     //     $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, total_detpenjualan, jumlah_final) VALUES (?, ?, ?)";
//     //     $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//     //     mysqli_stmt_bind_param($stmtInsertKartuGudang, "iii", $id_barang, $total_detpenjualan, $total_detpenjualan);
//     //     mysqli_stmt_execute($stmtInsertKartuGudang);
//     //   }
//     // }
//     // Insert data ke tabel detail_penjualan hanya sekali setelah update harga_penjualan
//     $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//     $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtInsertDetail);

//     mysqli_close($connection);
//     mysqli_stmt_close($stmtInsertDetail);

//     header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
//   }
// }


// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   //  value yang akan dikirim ke tabel detail_penjualan dari form detail_penjualan
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   // ambil harga_barang dari tabel barang berdasarkan id_barang
//   $ambilHargaQuery = "SELECT id_barang, harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   // ambil harga_penjualan dari tabel penjualan berdasarkan id_penjualan
//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     // Hitung jumlah_detpenjualan dan update harga_penjualan pada tabel penjualan
//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;
//     $harga_penjualan = $harga_penjualan + $jumlah_detpenjualan;

//     // Update harga_penjualan pada tabel penjualan
//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);

//     // Check apakah sudah ada data pada tabel kartu_gudang untuk id_barang tersebut
//     $checkKartuGudangQuery = "SELECT id_barang, jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//     $stmtCheckKartuGudang = mysqli_prepare($connection, $checkKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtCheckKartuGudang, "i", $id_barang);
//     mysqli_stmt_execute($stmtCheckKartuGudang);
//     $resultCheckKartuGudang = mysqli_stmt_get_result($stmtCheckKartuGudang);

//     if ($rowCheckKartuGudang = mysqli_fetch_assoc($resultCheckKartuGudang)) {
//       $jumlah_final_barang = $rowCheckKartuGudang['jumlah_final'] - $total_detpenjualan;
//     } else {
//       $ambilJumlahFinalQuery = "SELECT jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//       $stmtAmbilJumlahFinal = mysqli_prepare($connection, $ambilJumlahFinalQuery);
//       mysqli_stmt_bind_param($stmtAmbilJumlahFinal, "i", $id_barang);
//       mysqli_stmt_execute($stmtAmbilJumlahFinal);
//       $resultAmbilJumlahFinal = mysqli_stmt_get_result($stmtAmbilJumlahFinal);
//       $rowAmbilJumlahFinal = mysqli_fetch_assoc($resultAmbilJumlahFinal);
//       $jumlah_final_barang = $rowAmbilJumlahFinal['jumlah_final'] - $total_detpenjualan;
//     }

//     // Insert/update data pada tabel kartu_gudang
//     $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
//     $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
//     mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
//     mysqli_stmt_execute($stmtAmbilKode);
//     $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
//     $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
//     $kode_barang = $rowAmbilKode['kode_barang'];
//     $tanggal = date('Y-m-d');
//     $jumlah_final_barang = $rowCheckKartuGudang['jumlah_final'] - $total_detpenjualan;


//     $insertOrUpdateKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, total_detpenjualan, jumlah_final, kode_barang, tanggal) 
//     VALUES (?, ?, ?, ?, ?) 
//     ON DUPLICATE KEY UPDATE total_detpenjualan = total_detpenjualan - VALUES(total_detpenjualan), jumlah_final = ?";
//     $stmtInsertOrUpdateKartuGudang = mysqli_prepare($connection, $insertOrUpdateKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtInsertOrUpdateKartuGudang, "iiissi", $id_barang, $total_detpenjualan, $jumlah_final_barang, $kode_barang, $tanggal, $jumlah_final_barang);
//     mysqli_stmt_execute($stmtInsertOrUpdateKartuGudang);


//     $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) 
//     VALUES (?, ?, ?, ?, ?)";
//     $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtInsertDetail);


//     mysqli_close($connection);
//     mysqli_stmt_close($stmtInsertDetail);

//     header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
//   }
// }



// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   $ambilHargaQuery = "SELECT harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;
//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);

//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;

//     // Check apakah sudah ada data pada tabel kartu_gudang untuk id_barang tersebut
//     $checkKartuGudangQuery = "SELECT id_barang FROM kartu_gudang WHERE id_barang = ?";
//     $stmtCheckKartuGudang = mysqli_prepare($connection, $checkKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtCheckKartuGudang, "i", $id_barang);
//     mysqli_stmt_execute($stmtCheckKartuGudang);
//     $resultCheckKartuGudang = mysqli_stmt_get_result($stmtCheckKartuGudang);

//     if ($rowCheckKartuGudang = mysqli_fetch_assoc($resultCheckKartuGudang)) {

//       $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
//       $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
//       mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
//       mysqli_stmt_execute($stmtAmbilKode);
//       $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
//       $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
//       $kode_barang = $rowAmbilKode['kode_barang'];

//       $ambilJumlahFinalQuery = "SELECT jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//       $stmtAmbilJumlahFinal = mysqli_prepare($connection, $ambilJumlahFinalQuery);
//       mysqli_stmt_bind_param($stmtAmbilJumlahFinal, "i", $id_barang);
//       mysqli_stmt_execute($stmtAmbilJumlahFinal);
//       $resultAmbilJumlahFinal = mysqli_stmt_get_result($stmtAmbilJumlahFinal);
//       $rowAmbilJumlahFinal = mysqli_fetch_assoc($resultAmbilJumlahFinal);
//       $jumlah_final_barang = $rowAmbilJumlahFinal['jumlah_final'] - $total_detpenjualan;



//       $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, total_detpenjualan, jumlah_final, kode_barang) VALUES (?, ?, ?, ?)";
//       $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//       mysqli_stmt_bind_param($stmtInsertKartuGudang, "iiis", $id_barang, $total_detpenjualan, $jumlah_final_barang, $kode_barang);
//       mysqli_stmt_execute($stmtInsertKartuGudang);
//     }

//     $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//     $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtInsertDetail);

//     mysqli_close($connection);
//     mysqli_stmt_close($stmtInsertDetail);

//     header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
//   }
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id_barang = $_POST['id_barang'];
  $total_detpenjualan = $_POST['total_detpenjualan'];
  $id_penjualan = $_POST['id_penjualan'];

  $connection = mysqli_connect($servername, $username, $password, $database);

  $ambilHargaQuery = "SELECT harga_barang FROM barang WHERE id_barang = ?";
  $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
  mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
  mysqli_stmt_execute($stmtAmbilHarga);
  $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
  $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
  $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

  $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
  $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
  mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
  mysqli_stmt_execute($stmtAmbilHargaJual);
  $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
  $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
  $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

  if (!empty($harga_detpenjualan)) {
    $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;
    $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
    $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
    mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
    mysqli_stmt_execute($stmtUpdateHargaJual);

    $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;

    $checkKartuGudangQuery = "SELECT id_barang, jumlah_final FROM kartu_gudang WHERE id_barang = ?";
    $stmtCheckKartuGudang = mysqli_prepare($connection, $checkKartuGudangQuery);
    mysqli_stmt_bind_param($stmtCheckKartuGudang, "i", $id_barang);
    mysqli_stmt_execute($stmtCheckKartuGudang);
    $resultCheckKartuGudang = mysqli_stmt_get_result($stmtCheckKartuGudang);

    if ($rowCheckKartuGudang = mysqli_fetch_assoc($resultCheckKartuGudang)) {
      $jumlah_final_gudang = $rowCheckKartuGudang['jumlah_final'];

      if ($jumlah_final_gudang > 0) {
        $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
        $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
        mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
        mysqli_stmt_execute($stmtAmbilKode);
        $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
        $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
        $kode_barang = $rowAmbilKode['kode_barang'];
        $tanggal = date('Y-m-d');

        $ambilJumlahFinalQuery = "SELECT jumlah_final FROM kartu_gudang WHERE id_barang = ? ORDER BY id DESC LIMIT 1";
        $stmtAmbilJumlahFinal = mysqli_prepare($connection, $ambilJumlahFinalQuery);
        mysqli_stmt_bind_param($stmtAmbilJumlahFinal, "i", $id_barang);
        mysqli_stmt_execute($stmtAmbilJumlahFinal);
        $resultAmbilJumlahFinal = mysqli_stmt_get_result($stmtAmbilJumlahFinal);
        $rowAmbilJumlahFinal = mysqli_fetch_assoc($resultAmbilJumlahFinal);
        $jumlah_final_barang = $rowAmbilJumlahFinal['jumlah_final'] - $total_detpenjualan;


        $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, total_detpenjualan, jumlah_final, kode_barang, tanggal) VALUES (?, ?, ?, ?, ?)";
        $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
        mysqli_stmt_bind_param($stmtInsertKartuGudang, "iiiss", $id_barang, $total_detpenjualan, $jumlah_final_barang, $kode_barang, $tanggal);
        mysqli_stmt_execute($stmtInsertKartuGudang);

        $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
        $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
        mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
        mysqli_stmt_execute($stmtInsertDetail);

        mysqli_close($connection);
        mysqli_stmt_close($stmtInsertDetail);

        header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
      } else {
        echo "Jumlah final di kartu gudang sudah habis.";
      }
    }
  }
}




// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   // Ambil harga_barang dari tabel barang berdasarkan id_barang
//   $ambilHargaQuery = "SELECT harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   // Ambil harga_penjualan dari tabel penjualan berdasarkan id_penjualan
//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     // Cek apakah data sudah ada dalam detail_penjualan
//     $checkDetailPenjualanQuery = "SELECT id_penjualan FROM detail_penjualan WHERE id_penjualan = ? AND id_barang = ?";
//     $stmtCheckDetailPenjualan = mysqli_prepare($connection, $checkDetailPenjualanQuery);
//     mysqli_stmt_bind_param($stmtCheckDetailPenjualan, "ii", $id_penjualan, $id_barang);
//     mysqli_stmt_execute($stmtCheckDetailPenjualan);
//     $resultCheckDetailPenjualan = mysqli_stmt_get_result($stmtCheckDetailPenjualan);

//     $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//     $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtInsertDetail);

//     $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;

//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);

//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;

//     // Check apakah sudah ada data pada tabel kartu_gudang untuk id_barang tersebut
//     $checkKartuGudangQuery = "SELECT id_barang, jumlah_final FROM kartu_gudang WHERE id_barang = ?";
//     $stmtCheckKartuGudang = mysqli_prepare($connection, $checkKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtCheckKartuGudang, "i", $id_barang);
//     mysqli_stmt_execute($stmtCheckKartuGudang);
//     $resultCheckKartuGudang = mysqli_stmt_get_result($stmtCheckKartuGudang);

//     if ($rowCheckKartuGudang = mysqli_fetch_assoc($resultCheckKartuGudang)) {
//       // Jika id_barang sudah ada dalam kartu_gudang, update stok
//       $jumlah_final = $rowCheckKartuGudang['jumlah_final'] - $total_detpenjualan;

//       $updateKartuGudangFinalQuery = "UPDATE kartu_gudang SET total_detpenjualan = total_detpenjualan + ?, jumlah_final = ? WHERE id_barang = ?";
//       $stmtUpdateKartuGudangFinal = mysqli_prepare($connection, $updateKartuGudangFinalQuery);
//       mysqli_stmt_bind_param($stmtUpdateKartuGudangFinal, "iii", $total_detpenjualan, $jumlah_final, $id_barang);
//       mysqli_stmt_execute($stmtUpdateKartuGudangFinal);
//     } else {
//       // // Jika id_barang belum ada dalam kartu_gudang, masukkan data baru
//       $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, kode_barang, total_detpenjualan, jumlah_final, tanggal) VALUES (?, ?, ?, ?, ?)";
//       $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//       mysqli_stmt_bind_param($stmtInsertKartuGudang, "isiii", $id_barang, $kode_barang, $total_detpenjualan, $total_detpenjualan, $tanggal);
//       mysqli_stmt_execute($stmtInsertKartuGudang);
//       var_dump("Inserting new data into kartu_gudang");
//       $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//       mysqli_stmt_bind_param($stmtInsertKartuGudang, "isiii", $id_barang, $kode_barang, $total_detpenjualan, $total_detpenjualan, $tanggal);
//       mysqli_stmt_execute($stmtInsertKartuGudang);
//       var_dump("Inserted into kartu_gudang");
//     }


//     // Cek apakah data sudah ada dalam detail_penjualan



//     // if (mysqli_num_rows($resultCheckDetailPenjualan) === 0) {
//     //   // Jika data belum ada dalam detail_penjualan, masukkan data baru
//     //   $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//     //   $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     //   mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     //   mysqli_stmt_execute($stmtInsertDetail);
//     // } else {
//     //   // Jika data sudah ada, Anda dapat memberikan pesan kesalahan atau melakukan tindakan lain yang sesuai.
//     //   echo "Data with the same id_barang and id_penjualan already exists in detail_penjualan";
//     // }



//     // $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//     // $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//     // mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//     // mysqli_stmt_execute($stmtInsertDetail);

//     mysqli_close($connection);
//     mysqli_stmt_close($stmtInsertDetail);

//     header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
//   }
// }



// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   if (!$connection) {
//     die("Connection failed: " . mysqli_connect_error());
//   }

//   $ambilHargaQuery = "SELECT id_barang, harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;

//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);

//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;
//   }

//   $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//   $stmtInsertDetail = mysqli_prepare($connection, $insertQuery);
//   mysqli_stmt_bind_param($stmtInsertDetail, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);
//   $insertDetailResult = mysqli_stmt_execute($stmtInsertDetail);

//   if ($insertDetailResult) {
//     // $getPreviousDataQuery = "SELECT total_detpembelian, jumlah_final FROM kartu_gudang WHERE id_barang = ? ORDER BY id DESC LIMIT 1";
//     // $stmtGetPreviousData = mysqli_prepare($connection, $getPreviousDataQuery);
//     // mysqli_stmt_bind_param($stmtGetPreviousData, "i", $id_barang);
//     // mysqli_stmt_execute($stmtGetPreviousData);
//     // $resultPreviousData = mysqli_stmt_get_result($stmtGetPreviousData);
//     // $rowPreviousData = mysqli_fetch_assoc($resultPreviousData);

//     // $total_detpembelian_previous = $rowPreviousData['total_detpembelian'];
//     // $jumlah_final_previous = $rowPreviousData['jumlah_final'];

//     // $total_detpembelian_new = null;
//     // $total_detpenjualan_new = $total_detpenjualan;
//     // $jumlah_final_new = $jumlah_final_previous - $total_detpenjualan;

//     // $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, kode_barang, total_detpembelian, total_detpenjualan, jumlah_final, tanggal) VALUES (?, ?, ?, ?, ?, ?)";
//     // $stmtKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//     // mysqli_stmt_bind_param($stmtKartuGudang, "isiisi", $id_barang, $kode_barang, $total_detpembelian_new, $total_detpenjualan_new, $jumlah_final_new, $tanggal);

//     // $insertKartuGudangResult = mysqli_stmt_execute($stmtKartuGudang);

//     // if ($insertKartuGudangResult) {
//     //   echo "Data inserted into kartu_gudang successfully";
//     // } else {
//     //   echo "Error inserting data into kartu_gudang: " . mysqli_error($connection);
//     // }
//   } else {
//     echo "Error inserting data into detail_penjualan: " . mysqli_error($connection);
//   }

//   mysqli_close($connection);
//   mysqli_stmt_close($stmtInsertDetail);

//   header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
// }


// if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//   $id_barang = $_POST['id_barang'];
//   $total_detpenjualan = $_POST['total_detpenjualan'];
//   $id_penjualan = $_POST['id_penjualan'];

//   $connection = mysqli_connect($servername, $username, $password, $database);

//   $ambilHargaQuery = "SELECT id_barang, harga_barang FROM barang WHERE id_barang = ?";
//   $stmtAmbilHarga = mysqli_prepare($connection, $ambilHargaQuery);
//   mysqli_stmt_bind_param($stmtAmbilHarga, "i", $id_barang);
//   mysqli_stmt_execute($stmtAmbilHarga);
//   $resultAmbilHarga = mysqli_stmt_get_result($stmtAmbilHarga);
//   $rowAmbilHarga = mysqli_fetch_assoc($resultAmbilHarga);
//   $harga_detpenjualan = $rowAmbilHarga['harga_barang'];

//   $ambilHargaJual = "SELECT harga_penjualan FROM penjualan WHERE id_penjualan = ?";
//   $stmtAmbilHargaJual = mysqli_prepare($connection, $ambilHargaJual);
//   mysqli_stmt_bind_param($stmtAmbilHargaJual, "i", $id_penjualan);
//   mysqli_stmt_execute($stmtAmbilHargaJual);
//   $resultAmbilHargaJual = mysqli_stmt_get_result($stmtAmbilHargaJual);
//   $rowAmbilHargaJual = mysqli_fetch_assoc($resultAmbilHargaJual);
//   $harga_penjualan = $rowAmbilHargaJual['harga_penjualan'];

//   if (!empty($harga_detpenjualan)) {
//     $harga_penjualan = $harga_detpenjualan * $total_detpenjualan;

//     $updateHargaJualQuery = "UPDATE penjualan SET harga_penjualan = ? WHERE id_penjualan = ?";
//     $stmtUpdateHargaJual = mysqli_prepare($connection, $updateHargaJualQuery);
//     mysqli_stmt_bind_param($stmtUpdateHargaJual, "di", $harga_penjualan, $id_penjualan);
//     mysqli_stmt_execute($stmtUpdateHargaJual);

//     $jumlah_detpenjualan = $total_detpenjualan * $harga_detpenjualan;

//     // Update kartu_gudang: kurangi total_detpembelian dengan total_detpenjualan
//     $updateKartuGudangQuery = "UPDATE kartu_gudang SET total_detpembelian = total_detpembelian - ? WHERE id_barang = ?";
//     $stmtUpdateKartuGudang = mysqli_prepare($connection, $updateKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtUpdateKartuGudang, "ii", $total_detpenjualan, $id_barang);
//     mysqli_stmt_execute($stmtUpdateKartuGudang);

//     // Calculate jumlah_final
//     $jumlah_final = $total_detpembelian - $total_detpenjualan;

//     // Insert new row into kartu_gudang
//     $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, kode_barang, total_detpenjualan, total_detpembelian, jumlah_final, tanggal) VALUES (?, ?, ?, ?, ?, ?)";
//     $stmtInsertKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtInsertKartuGudang, "isisis", $id_barang, $kode_barang, $total_detpenjualan, $total_detpenjualan, $jumlah_final, $tanggal);

//     if (mysqli_stmt_execute($stmtInsertKartuGudang)) {
//       echo "Data inserted into kartu_gudang successfully";
//     } else {
//       echo "Error inserting data into kartu_gudang: " . mysqli_error($connection);
//     }
//   }

//   $insertQuery = "INSERT INTO detail_penjualan (id_barang, jumlah_detpenjualan, harga_detpenjualan, total_detpenjualan, id_penjualan) VALUES (?, ?, ?, ?, ?)";
//   $stmt = mysqli_prepare($connection, $insertQuery);
//   mysqli_stmt_bind_param($stmt, "iiiii", $id_barang, $jumlah_detpenjualan, $harga_detpenjualan, $total_detpenjualan, $id_penjualan);

//   if (mysqli_stmt_execute($stmt)) {
//     echo "Data inserted successfully";

//     $insertedId = $id_barang;
//     $jumlah_final = $total_detpenjualan;
//     $tanggal = date('Y-m-d');

//     $ambilKodeQuery = "SELECT kode_barang FROM barang WHERE id_barang = ?";
//     $stmtAmbilKode = mysqli_prepare($connection, $ambilKodeQuery);
//     mysqli_stmt_bind_param($stmtAmbilKode, "i", $id_barang);
//     mysqli_stmt_execute($stmtAmbilKode);
//     $resultAmbilKode = mysqli_stmt_get_result($stmtAmbilKode);
//     $rowAmbilKode = mysqli_fetch_assoc($resultAmbilKode);
//     $kode_barang = $rowAmbilKode['kode_barang'];

//     $insertKartuGudangQuery = "INSERT INTO kartu_gudang (id_barang, kode_barang, total_detpenjualan, jumlah_final, tanggal) VALUES (?, ?, ?, ?, ?)";
//     $stmtKartuGudang = mysqli_prepare($connection, $insertKartuGudangQuery);
//     mysqli_stmt_bind_param($stmtKartuGudang, "isiis", $insertedId, $kode_barang, $total_detpenjualan, $jumlah_final, $tanggal);

//     if (mysqli_stmt_execute($stmtKartuGudang)) {
//       echo "Data inserted into kartu_gudang successfully";
//     } else {
//       echo "Error inserting data into kartu_gudang: " . mysqli_error($connection);
//     }
//   } else {
//     echo "Failed to insert data";
//   }

//   mysqli_close($connection);
//   mysqli_stmt_close($stmt);

//   header('Location: ../views/detail_penjualan.php?id_penjualan=' . $id_penjualan);
// }


 // jika data detail_penjualan berhasil, maka update kartu stok
  // if (mysqli_stmt_execute($stmt)) {
  //   echo "Data inserted successfully";



























































  //   // $id_detpenjualan = mysqli_insert_id($connection);
  //   // $tanggal_ks = date('Y-m-d');

  //   // // periksa apakah id_barang sudah ada data sebelumnya atay tidak?
  //   // $selectPrevDataQuery = "SELECT * FROM kartu_stok WHERE id_barang = ? ORDER BY insert_order DESC";
  //   // $stmtPrevData = mysqli_prepare($connection, $selectPrevDataQuery);
  //   // mysqli_stmt_bind_param($stmtPrevData, "i", $id_barang);
  //   // mysqli_stmt_execute($stmtPrevData);
  //   // // mendapatkan data barang sebelumnya
  //   // $prevDataList = mysqli_stmt_get_result($stmtPrevData);
  //   // $total_out_ks = 0;
  //   // $remainingQuantity = $total_detpenjualan;

  //   // // Looping untuk mendapatkan stok barang yang tersedia
  //   // while ($prevData = mysqli_fetch_assoc($prevDataList)) {
  //   //   $availableQuantity = $prevData['total_in_ks'] - $prevData['total_out_ks'];
  //   //   $harga_in_ks = $prevData['harga_in_ks'];

  //   //   if ($remainingQuantity <= $availableQuantity) {
  //   //     // Jika jumlah yang terjual kurang dari atau sama dengan stok tersedia pada entri stok tertua
  //   //     $total_final_ks = $prevData['total_in_ks'] - $total_out_ks;
  //   //     $harga_final_ks = $harga_in_ks;
  //   //     $jumlah_final_ks = $total_final_ks * $harga_final_ks;
  //   //     $total_out_ks += $remainingQuantity;
  //   //     break;
  //   //   } else {
  //   //     // Jika jumlah yang terjual melebihi stok tersedia pada entri stok tertua
  //   //     $total_out_ks += $availableQuantity;
  //   //     $remainingQuantity -= $availableQuantity;
  //   //     // Update nilai total_final_ks untuk entri stok tertua
  //   //     // $updateKartuStokQuery = "UPDATE kartu_stok SET total_final_ks = 0 WHERE id_ks = ?";
  //   //     // $stmtUpdateKartuStok = mysqli_prepare($connection, $updateKartuStokQuery);
  //   //     // mysqli_stmt_bind_param($stmtUpdateKartuStok, "i", $prevData['id_ks']);
  //   //     // mysqli_stmt_execute($stmtUpdateKartuStok);
  //   //     // mysqli_stmt_close($stmtUpdateKartuStok);
  //   //   }
  //   // }

  //   // if ($remainingQuantity > 0) {
  //   //   // Jika stok masih tersisa setelah mengambil dari stok tertua
  //   //   $total_final_ks = $remainingQuantity;
  //   //   $harga_final_ks = $harga_detpenjualan;
  //   //   $jumlah_final_ks = $total_final_ks * $harga_final_ks;
  //   // }

  //   // // Periksa apakah id_barang dari detail_penjualan sama dengan id_barang pada tabel kartu_stok
  //   // $checkKartuStokQuery = "SELECT * FROM kartu_stok WHERE id_barang = ? ORDER BY insert_order DESC LIMIT 1";

  //   // $stmtCheckKartuStok = mysqli_prepare($connection, $checkKartuStokQuery);
  //   // mysqli_stmt_bind_param($stmtCheckKartuStok, "i", $id_barang);
  //   // mysqli_stmt_execute($stmtCheckKartuStok);
  //   // $latestKartuStok = mysqli_stmt_get_result($stmtCheckKartuStok);

  //   // if (mysqli_num_rows($latestKartuStok) > 0) {
  //   //   $row = mysqli_fetch_assoc($latestKartuStok);
  //   //   $prev_total_final_ks = $row['total_final_ks'];

  //   //   // Jika total_out_ks tidak lebih dari total_final_ks sebelumnya, lakukan pengurangan
  //   //   if ($total_out_ks <= $prev_total_final_ks) {
  //   //     $total_final_ks = $prev_total_final_ks - $total_out_ks;
  //   //     // Hitung nilai jumlah_final_ks
  //   //     $jumlah_final_ks = $total_final_ks * $harga_final_ks;
  //   //   }
  //   // }


  //   // // memasukan data kedalam table kartu_stok
  //   // $insertKartuStokQuery = "INSERT INTO kartu_stok (id_detpenjualan, tanggal_ks, total_out_ks, harga_out_ks, jumlah_out_ks, total_final_ks, harga_final_ks, jumlah_final_ks, id_barang, insert_order) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
  //   // $stmtInsertKartuStok = mysqli_prepare($connection, $insertKartuStokQuery);
  //   // mysqli_stmt_bind_param($stmtInsertKartuStok, "isisiiiiii", $id_detpenjualan, $tanggal_ks, $total_detpenjualan, $harga_detpenjualan, $jumlah_detpenjualan, $total_final_ks, $harga_final_ks, $jumlah_final_ks, $id_barang, $id_detpenjualan);

  //   // if (mysqli_stmt_execute($stmtInsertKartuStok)) {
  //   //   echo "Data inserted into kartu stok successfully";
  //   // } else {
  //   //   echo "Failed to insert data into kartu stok";
  //   // }

  //   // // Close the connections
  //   // mysqli_stmt_close($stmtPrevData);
  //   // mysqli_stmt_close($stmtInsertKartuStok);
  //   // mysqli_stmt_close($stmtCheckKartuStok);
  // } else {
  //   echo "Failed to insert data";
  // }
