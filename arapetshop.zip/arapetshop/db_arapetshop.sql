-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Aug 29, 2023 at 01:50 PM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_arapetshop`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int NOT NULL,
  `kode_barang` varchar(5) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nama_barang` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `id_kategori` int DEFAULT NULL,
  `harga_barang` int DEFAULT NULL,
  `deskripsi_barang` text COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `kode_barang`, `nama_barang`, `id_kategori`, `harga_barang`, `deskripsi_barang`) VALUES
(24, 'BRG01', 'Kandang Kucing', 4, 300000, 'kandang kucing semua usia'),
(25, 'BRG02', 'Wishcash Puch', 1, 15000, 'Makanan kucing usia -1 tahun');

-- --------------------------------------------------------

--
-- Table structure for table `detail_pembelian`
--

CREATE TABLE `detail_pembelian` (
  `id_detpembelian` int NOT NULL,
  `id_barang` int DEFAULT NULL,
  `jumlah_detpembelian` int DEFAULT NULL,
  `harga_detpembelian` int DEFAULT NULL,
  `total_detpembelian` int DEFAULT NULL,
  `id_pembelian` int DEFAULT NULL,
  `tanggal_detpembelian` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_pembelian`
--

INSERT INTO `detail_pembelian` (`id_detpembelian`, `id_barang`, `jumlah_detpembelian`, `harga_detpembelian`, `total_detpembelian`, `id_pembelian`, `tanggal_detpembelian`) VALUES
(222, 24, 500000, 100000, 5, 152, NULL),
(224, 25, 150000, 15000, 10, 154, NULL),
(226, 24, 600000, 300000, 2, 156, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `detail_penjualan`
--

CREATE TABLE `detail_penjualan` (
  `id_detpenjualan` int NOT NULL,
  `id_barang` int DEFAULT NULL,
  `jumlah_detpenjualan` int DEFAULT NULL,
  `harga_detpenjualan` int DEFAULT NULL,
  `total_detpenjualan` int DEFAULT NULL,
  `tanggal_detpenjualan` date DEFAULT NULL,
  `id_penjualan` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `detail_penjualan`
--

INSERT INTO `detail_penjualan` (`id_detpenjualan`, `id_barang`, `jumlah_detpenjualan`, `harga_detpenjualan`, `total_detpenjualan`, `tanggal_detpenjualan`, `id_penjualan`) VALUES
(442, 24, 285000, 95000, 3, NULL, 239),
(443, 24, 95000, 95000, 1, NULL, 240),
(444, 24, 95000, 95000, 1, NULL, 241),
(445, 25, 105000, 15000, 7, NULL, 242),
(446, 25, 45000, 15000, 3, NULL, 243),
(450, 24, 600000, 300000, 2, NULL, 247);

-- --------------------------------------------------------

--
-- Table structure for table `kartu_gudang`
--

CREATE TABLE `kartu_gudang` (
  `id` int NOT NULL,
  `kode_barang` varchar(255) DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `total_detpembelian` int DEFAULT NULL,
  `total_detpenjualan` int DEFAULT NULL,
  `jumlah_final` int DEFAULT NULL,
  `tanggal` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kartu_gudang`
--

INSERT INTO `kartu_gudang` (`id`, `kode_barang`, `id_barang`, `total_detpembelian`, `total_detpenjualan`, `jumlah_final`, `tanggal`) VALUES
(106, 'BRG01', 24, 5, NULL, 5, '2023-08-29'),
(126, 'BRG01', 24, NULL, 3, 2, '2023-08-29'),
(127, 'BRG01', 24, NULL, 1, 1, '2023-08-29'),
(128, 'BRG01', 24, NULL, 1, 0, '2023-08-29'),
(129, 'BRG02', 25, 10, NULL, 10, '2023-08-29'),
(130, 'BRG02', 25, NULL, 7, 3, '2023-08-29'),
(131, 'BRG02', 25, NULL, 3, 0, '2023-08-29'),
(136, 'BRG01', 24, 2, NULL, 2, '2023-08-29'),
(137, 'BRG01', 24, NULL, 2, 0, '2023-08-29');

-- --------------------------------------------------------

--
-- Table structure for table `kartu_stok`
--

CREATE TABLE `kartu_stok` (
  `id_ks` int NOT NULL,
  `tanggal_ks` date DEFAULT NULL,
  `id_detpembelian` int DEFAULT NULL,
  `total_in_ks` int DEFAULT NULL,
  `harga_in_ks` int DEFAULT NULL,
  `jumlah_in_ks` int DEFAULT NULL,
  `total_out_ks` int DEFAULT NULL,
  `harga_out_ks` int DEFAULT NULL,
  `jumlah_out_ks` int DEFAULT NULL,
  `total_final_ks` int DEFAULT NULL,
  `harga_final_ks` int DEFAULT NULL,
  `jumlah_final_ks` int DEFAULT NULL,
  `id_detpenjualan` int DEFAULT NULL,
  `id_barang` int DEFAULT NULL,
  `insert_order` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int NOT NULL,
  `nama_kategori` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Makanan'),
(2, 'Minuman'),
(3, 'Obat'),
(4, 'Peralatan / Perlengkapan');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE `pembelian` (
  `id_pembelian` int NOT NULL,
  `notransaksi_pembelian` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_pembelian` date DEFAULT NULL,
  `id_supplier` int DEFAULT NULL,
  `harga_pembelian` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`id_pembelian`, `notransaksi_pembelian`, `tanggal_pembelian`, `id_supplier`, `harga_pembelian`) VALUES
(152, NULL, '2023-08-29', NULL, 500000),
(154, NULL, '2023-08-30', NULL, 150000),
(156, NULL, '2023-08-31', NULL, 600000);

-- --------------------------------------------------------

--
-- Table structure for table `penjualan`
--

CREATE TABLE `penjualan` (
  `id_penjualan` int NOT NULL,
  `kode_penjualan` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tanggal_penjualan` date DEFAULT NULL,
  `harga_penjualan` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penjualan`
--

INSERT INTO `penjualan` (`id_penjualan`, `kode_penjualan`, `tanggal_penjualan`, `harga_penjualan`) VALUES
(239, NULL, '2023-08-30', 285000),
(240, NULL, '2023-08-30', 95000),
(241, NULL, '2023-08-30', 95000),
(242, NULL, '2023-08-30', 105000),
(243, NULL, '2023-08-31', 45000),
(247, NULL, '2023-08-30', 600000);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id_supplier` int NOT NULL,
  `nama_supplier` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `telp_supplier` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alamat_supplier` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id_supplier`, `nama_supplier`, `telp_supplier`, `alamat_supplier`) VALUES
(1, 'CV. Maju Lancar', '081245639824', 'Jl. Ringroad Utara No.115 Sleman, Yogyakarta'),
(3, 'CV. Naga Mas', '082293889498', 'Jl. Ringroad Barat No.190, Bantul, Yogyakarta\r\n'),
(4, 'test', '981723987', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `name`, `email`, `password`, `role`) VALUES
(1, 'jessica', 'jessica@arapetshop.com', 'admin', 'Manager');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD UNIQUE KEY `uq_kode_barang` (`kode_barang`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD PRIMARY KEY (`id_detpembelian`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_pembelian` (`id_pembelian`);

--
-- Indexes for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD PRIMARY KEY (`id_detpenjualan`),
  ADD KEY `id_penjualan` (`id_penjualan`),
  ADD KEY `id_barang` (`id_barang`) USING BTREE;

--
-- Indexes for table `kartu_gudang`
--
ALTER TABLE `kartu_gudang`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `total_detpembelian` (`total_detpembelian`,`total_detpenjualan`);

--
-- Indexes for table `kartu_stok`
--
ALTER TABLE `kartu_stok`
  ADD PRIMARY KEY (`id_ks`),
  ADD KEY `id_detpembelian` (`id_detpembelian`),
  ADD KEY `id_detpenjualan` (`id_detpenjualan`),
  ADD KEY `id_barang` (`id_barang`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`id_pembelian`),
  ADD KEY `id_supplier` (`id_supplier`);

--
-- Indexes for table `penjualan`
--
ALTER TABLE `penjualan`
  ADD PRIMARY KEY (`id_penjualan`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id_supplier`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  MODIFY `id_detpembelian` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;

--
-- AUTO_INCREMENT for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  MODIFY `id_detpenjualan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=451;

--
-- AUTO_INCREMENT for table `kartu_gudang`
--
ALTER TABLE `kartu_gudang`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=138;

--
-- AUTO_INCREMENT for table `kartu_stok`
--
ALTER TABLE `kartu_stok`
  MODIFY `id_ks` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=308;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `pembelian`
--
ALTER TABLE `pembelian`
  MODIFY `id_pembelian` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `penjualan`
--
ALTER TABLE `penjualan`
  MODIFY `id_penjualan` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=248;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id_supplier` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`);

--
-- Constraints for table `detail_pembelian`
--
ALTER TABLE `detail_pembelian`
  ADD CONSTRAINT `detail_pembelian_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `detail_pembelian_ibfk_2` FOREIGN KEY (`id_pembelian`) REFERENCES `pembelian` (`id_pembelian`);

--
-- Constraints for table `detail_penjualan`
--
ALTER TABLE `detail_penjualan`
  ADD CONSTRAINT `detail_penjualan_ibfk_1` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `detail_penjualan_ibfk_2` FOREIGN KEY (`id_penjualan`) REFERENCES `penjualan` (`id_penjualan`);

--
-- Constraints for table `kartu_stok`
--
ALTER TABLE `kartu_stok`
  ADD CONSTRAINT `kartu_stok_ibfk_1` FOREIGN KEY (`id_detpembelian`) REFERENCES `detail_pembelian` (`id_detpembelian`),
  ADD CONSTRAINT `kartu_stok_ibfk_2` FOREIGN KEY (`id_detpenjualan`) REFERENCES `detail_penjualan` (`id_detpenjualan`),
  ADD CONSTRAINT `kartu_stok_ibfk_3` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`);

--
-- Constraints for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD CONSTRAINT `pembelian_ibfk_1` FOREIGN KEY (`id_supplier`) REFERENCES `supplier` (`id_supplier`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
