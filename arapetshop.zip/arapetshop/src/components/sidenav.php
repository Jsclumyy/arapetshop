 <!-- ======= Sidebar ======= -->
 <aside id="sidebar" class="sidebar">

   <ul class="sidebar-nav" id="sidebar-nav">

     <li class="nav-heading">Menu</li>

     <li class="nav-item">
       <a class="nav-link collapsed" href="dashboard.php">
         <i class="bi bi-grid"></i>
         <span>Dashboard</span>
       </a>
     </li><!-- End Dashboard Nav -->

     <li class="nav-item">
       <a href="supplier.php" class="nav-link collapsed">
         <i class="bi bi-truck"></i>
         <span>Data Supplier</span>
       </a>
     </li>

     <li class="nav-item">
       <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
         <i class="bi bi-clipboard-data"></i><span>Produk & Kategori</span><i class="bi bi-chevron-down ms-auto"></i>
       </a>
       <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
         <li class="nav-item">
           <a class="nav-link collapsed" href="produk.php">
             <i class="bi bi-circle"></i>
             <span>Data Produk</span>
           </a>
         </li>
         <li class="nav-item">
           <a class="nav-link collapsed" href="kategori.php">
             <i class="bi bi-circle"></i>
             <span>Data Kategori</span>
           </a>
         </li>
       </ul>
     </li>

     <li class="nav-heading">Pages</li>

     <li class="nav-item">
       <a class="nav-link collapsed" href="pembelian.php">
         <i class="bi bi-box-arrow-in-right"></i>
         <span>Pembelian</span>
       </a>
     </li>

     <li class="nav-item">
       <a class="nav-link collapsed" href="penjualan.php">
         <i class="bi bi-box-arrow-right"></i>
         <span>Penjualan</span>
       </a>
     </li>

     <li class="nav-item">
       <a href="kartugudang.php" class="nav-link collapsed">
         <i class="bi bi-file-earmark-spreadsheet-fill"></i>
         <span>Kartu Gudang</span>
       </a>
     </li>



   </ul>

 </aside><!-- End Sidebar-->