<?php
session_start();

require_once "../../functions.php";
require_once "../../koneksi.php";

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
  header("Location: ../../index.php");
  exit;
}

if (isset($_POST['logout'])) {
  // Call the logout function
  logout();
}

// get data suplier
$conn = mysqli_connect($servername, $username, $password, $database);
$query = 'SELECT supplier.id_supplier, supplier.nama_supplier, supplier.telp_supplier, supplier.alamat_supplier FROM supplier';
$result = mysqli_query($conn, $query)


?>

<?php require_once '../components/header.php' ?>
<?php require_once "../components/navbar.php"; ?>
<?php require_once "../components/sidenav.php" ?>

<main id="main" class="main">
  <div class="pagetitle">
    <h1>Data Supplier</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../views/Dashboard.php">Home</a></li>
        <li class="breadcrumb-item active">Data Supplier</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="card">
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="card-title">Data Supplier</h5>
          <button class="btn btn-sm btn-success" data-bs-toggle="modal" data-bs-target="#tambahsupplier">Tambah Supplier</button>
          <!-- modal -->
          <div class="modal fade" id="tambahsupplier">
            <div class="modal-dialog">
              <div class="modal-content">
                <div class="modal-header">
                  <h1 class="modal-title fs-5" id="exampleModalLabel">Tambah Supplier</h1>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">

                  <form action="../process/proses_form_supplier.php" method="POST">
                    <div class="mb-3">
                      <label class="form-label">Nama Supplier</label>
                      <input type="text" class="form-control" placeholder="masukan nama supplier" name="nama_supplier">
                    </div>

                    <div class="mb-3">
                      <label class="form-label">Nomor Telepon</label>
                      <input type="number" class="form-control" placeholder="masukan nomor telepon" name="telp_supplier">
                    </div>

                    <div class="mb-3">
                      <label class="form-label">Alamat Supplier</label>
                      <textarea class="form-control" placeholder="masukan alamat suplier" name="alamat_supplier"></textarea>
                    </div>

                    <div class="d-flex justify-content-end">
                      <button type="submit" class="btn btn-sm btn-primary me-1">
                        <i class="bi bi-check-lg"></i>
                        Simpan
                      </button>
                      <button type="button" class="btn btn-secondary btn-sm btn-warning" data-bs-dismiss="modal">
                        <i class="bi bi-x-lg"></i>
                        Batal
                      </button>
                    </div>
                  </form>

                </div>
              </div>
            </div>
          </div>
        </div>
        <hr>
        <table class="table table-responsive table-bordered border-dark text-center">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Supplier</th>
              <th>Nomor Telepon</th>
              <th>Alamat</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $nomor = 1;
            if ($result && mysqli_num_rows($result) > 0) {
              while ($row = mysqli_fetch_assoc($result)) {
                $nama = $row['nama_supplier'];
                $telp = $row['telp_supplier'];
                $alamat = $row['alamat_supplier'];

                echo "<tr>";
                echo "<td>$nomor</td>";
                $nomor++;
                echo "<td>$nama</td>";
                echo "<td>$telp</td>";
                echo "<td>$alamat</td>";
                echo "</tr>";
              }
            } else {
              echo "<tr><td colspan='3'>No data found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>

</main>

<?php require_once "../components/footer.php" ?>