<?php
if (isset($_GET['login']) && $_GET['login'] === 'success') {
  echo <<<HTML
    <script>
      document.addEventListener('DOMContentLoaded', function() {
        var toast = new bootstrap.Toast(document.getElementById('loginToast'));
        toast.show();
      });
    </script>

    <div id="loginToast" class="toast position-fixed end-0 text-bg-success mt-2" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="3000">
      <div class="d-flex">
        <div class="toast-body">
        Selamat datang, {$_SESSION['user']['name']}!
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  HTML;
}
?>

<!-- ======= Header ======= -->
<header id="header" class="header fixed-top d-flex align-items-center ">

  <div class="d-flex align-items-center justify-content-between">
    <i class="bi bi-list toggle-sidebar-btn me-2"></i>
    <a href="index.html" class="logo d-flex align-items-center">
      <img src="../assets/favicon.ico" alt="">
      <span class="d-none d-lg-block">Ara Petshop</span>
    </a>
  </div><!-- End Logo -->

  <nav class="header-nav ms-auto">
    <ul class="d-flex align-items-center">
      <li class="nav-item dropdown pe-3">
        <?php if (isset($_SESSION['user'])) { ?>
          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="../assets/img/profile.png" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2"><?php echo $_SESSION['user']['name']; ?></span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <img src="../assets/img/profile.png" alt="Profile" class="rounded-circle" width="50px">
              <h6><?php echo $_SESSION['user']['name']; ?></h6>
              <span><?php echo $_SESSION['user']['role']; ?></span><br>
              <small class="text-muted"><?php echo $_SESSION['user']['email']; ?></small>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="/">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <form class="d-flex" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <button name="logout" type="submit" class="dropdown-item d-flex align-items-center">
                  <i class="bi bi-box-arrow-right"></i>
                  <span>Sign Out</span>
                </button>
              </form>
            </li>
          </ul><!-- End Profile Dropdown Items -->
        <?php } ?>
      </li><!-- End Profile Nav -->
    </ul>
  </nav><!-- End Icons Navigation -->


</header><!-- End Header -->